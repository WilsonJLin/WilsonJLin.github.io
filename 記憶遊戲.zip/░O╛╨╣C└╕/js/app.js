 /*
 * 创建一个包含所有卡片的数组
 */
var cardIcons = [
    'fa fa-diamond', 'fa fa-paper-plane-o',
    'fa fa-anchor', 'fa fa-bolt',
    'fa fa-cube', 'fa fa-anchor',
    'fa fa-leaf', 'fa fa-bicycle',
    'fa fa-diamond', 'fa fa-bomb',
    'fa fa-leaf', 'fa fa-bomb',
    'fa fa-bolt', 'fa fa-bicycle',
    'fa fa-paper-plane-o', 'fa fa-cube'
];

//利用jQ獲得DOM元素
const $deck = $('.deck');
const $stars = $('.stars');
const $moves = $('.moves');
const $gameTime = $('.game-time');
const $restartBtn = $('.restart');

//變量聲明
let openCards = [];
let matchedCardsNum = 0;
let moveCounter = 0;
let starNum = 3;
let startDate = null;
let finalTime = 0;
let timerID = null;
let firstClick = true;

//頁面準備好時
$(document).ready(function() {
  resetGameData();
  //點擊卡牌
  $deck.on('click', 'li', function(e) {
    const target = $(this);
    //第一次點擊卡牌就打開計時器
    if (firstClick) {
      timer();
      firstClick = false;
    }
    if (!target.hasClass('open')) {
      displayCardSymbol(target);
      addCardToOpenCards(target);
      if (openCards.length === 2) {
        showStepNum();
        getClassOfCardIcon(openCards[0]) === getClassOfCardIcon(openCards[1]);
        //判斷卡片是否匹配
        ? lockMatchedCard()
        ! hideCardSymbol();
      }
    }
  });
  $restartBtn.on('click', function() {
    resetGameData();
  });
});

//重置遊戲
function resetGameData() {
  clearInterval(timerID);

  openCards = [];
  matchedCardsNum = 0;
  moveCounter = 0;
  starNum = 3;
  startDate = null;
  finalTime = 0;
  timerID = null;
  firstClick = true;

  $moves.text('0');
  $deck.empty();
  $stars.html(starsHtml(starNum));
  $gameTime.text('0');

  shuffleCards(cardIcons);
}

function shuffleCards(arr) {
  //洗牌
  shuffle(arr);

  //將數組內容放到頁面中
  let str = '';
  for (let i = 0; i < arr.length; i++) {
    str = str + '<li class = "card"><i class = "fa ${arr[i]}"></i></li>\n';
  }
  $deck.html(str);
}


//計時器
function timer() {
  startDate = new Date();
  timerID = setInterval(function() {
    finalTime = Math.round((new Date() - startDate) / 1000);
    $gameTime.text(finalTime);
  }, 1000);
}


function getClassOfCardIcon(el) {
  return el.children().attr('class');
}
//移動次數與對照星級
function showStepNum() {
  $moves.empty();
  moveCounter++;

  if (moveCounter > 10 && moveCounter < 20) {
    starNum = 2;
  } else if (moveCounter > 20) {
    starNum = 1;
  }

  if (starNum !== 3) $stars.html(starsHtml(starNum));
}

//卡片顯示
function displayCardSymbol(element) {
  element.addClass('open show');
}

//將卡牌天家到openCard中
function addCardToOpenCards(element) {
  openCards.push(element);
}

//隱藏卡片
function hideCardsSymbol() {
  openCards.forEach(function(card) {
    card.attr('class', 'card open show error');
    srtTimeout(function () {
      card.attr('class', 'card');
    }, 1000);
  });
  openCards = [];
}

//如果卡片匹配，鎖定卡牌並確認遊戲是否結束
function lockMatchedCard() {
  openCards.forEach(function(card) {
    card.attr('class', 'card open match');
  });
  matchedCardsNum += 2;
  isGameOver();
  openCards = [];
}

//星星數量
function starsHtml(num) {
  let stars = "";
  for (let i = 0; i < num; i++) {
    stars += '<i class = "fa fa-star"></i>';
  }

  return stars;
}

//遊戲結束
function isGameOver() {
  if (matchedCardsNum === 16) {
    clearInterval(timerID);
    Swal({
      title: 'Congratulations!! Nicely Done.'
      type: 'info'
      html: '嘗試 ${moveCounter} 次, 花費 ${finalTime}, 評價 ${starsHtml(
        starNum
      )}',
      confirmButtonText: "Play again"
    }).then(function() {
      resetGameData();
    });
  }
}

// 洗牌函数
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}
